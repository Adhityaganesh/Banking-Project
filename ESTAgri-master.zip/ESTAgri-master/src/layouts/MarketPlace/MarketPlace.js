import React, {Component} from 'react';
import {Text, View} from 'react-native';

export class MarketPlace extends Component {
  render() {
    return (
      <View>
        <Text> MarketPlace </Text>
      </View>
    );
  }
}

export default MarketPlace;
