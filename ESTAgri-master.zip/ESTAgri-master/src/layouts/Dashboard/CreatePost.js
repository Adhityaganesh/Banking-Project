import React, {Component} from 'react';
import {
  SafeAreaView,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
  StyleSheet,
  BackHandler,
} from 'react-native';
import {TextInput, Button, ProgressBar, Checkbox} from 'react-native-paper';
import AgrxColors from '../../config/AgrxColors';
import * as Animatable from 'react-native-animatable';
import {connect} from 'react-redux';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import FastImage from 'react-native-fast-image';
import MaterialCommunityIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import {SAVE_DOCUMENT_DATA, UPLOAD_IMAGE} from '../../config/settings';
import ImagePicker from 'react-native-image-picker';
import Toast from 'react-native-simple-toast';
import RNFetchBlob from 'rn-fetch-blob';
import Spinner from '../../components/SpinnerOverlay';

export class CreatePost extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedImage: null,

      pressed: false,
      cropName: '',
      questionText: '',
      natureOfProblem: '',
    };
  }

  onChangeCropName = (text) => {
    this.setState({
      cropName: text,
    });
  };

  onChangeQuestion = (text) => {
    this.setState({
      questionText: text,
    });
  };

  onChangeCropNature = (text) => {
    this.setState({
      natureOfProblem: text,
    });
  };

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
    this.props.navigation.setOptions({
      headerTitle: 'Check with community',
    });
  }

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.handleBackButton);
  }

  handleBackButton = () => {
    this.props.navigation.goBack();

    return true;
  };

  imageTapped = (docType) => {
    this.setState({
      pressed: true,
    });
    const options = {
      storageOptions: {
        skipBackup: true,
        cameraRoll: true,
      },
      allowsEditing: true,
      mediaType: 'photo',
      saveToPhotos: false,
    };

    ImagePicker.showImagePicker(options, async (response) => {
      if (response.didCancel) {
        console.log(response.didCancel, 'response.didCancel');
        this.setState({
          pressed: false,
        });
      } else if (response.error) {
        console.log(response.error, 'response.error');
        this.setState({
          pressed: false,
        });
      } else if (response.customButton) {
        console.log(response.customButton, 'response.customButton');
        this.setState({
          pressed: false,
        });
      } else {
        this.setState({
          pressed: false,
          selectedImage: response,
          documentData: {
            ...this.state.documentData,
            idType: docType,
          },
        });
        console.log(response, 'response image');
      }
    });
  };

  uploadImage = () => {
    // this.setState({
    //   isLoading: false,
    //   imageSubmitted: true,
    //   progress: 0.33,
    // });
    // return;
    const {selectedImage} = this.state;
    const mobileNo = this.props.route.params.mobileNo;
    let body = [
      {
        name: 'file',
        filename: `IMG_${Date.now()}`,
        data:
          Platform.OS == 'android'
            ? RNFetchBlob.wrap(selectedImage.uri)
            : RNFetchBlob.wrap(selectedImage.uri.replace('file://', '')),
      },
      {
        name: 'mobileNo',
        data: mobileNo,
      },
    ];

    console.log(body, 'body');
    this.setState({
      isLoading: true,
    });

    RNFetchBlob.fetch(
      'POST',
      UPLOAD_IMAGE,
      {
        Accept: 'application/json',
        'Content-Type': 'multipart/form-data',
      },
      body,
    )
      .uploadProgress((written, total) => {
        console.log('uploaded', written / total);
        this.setState({
          uploadProgress: (written / total).toFixed(2) * 100,
        });
      })
      .then((resp) => {
        console.log('resp', resp);
        if (resp.data) {
          let docData = JSON.parse(resp.data);
          console.log(docData, 'docData');
          this.setState({
            isLoading: false,
            imageSubmitted: true,
            progress: 0.33,
            documentData: {
              ...this.state.documentData,
              idNumber: docData?.result?.documentNumber,
              name:
                docData?.result?.fullName.length > 0
                  ? docData?.result?.fullName
                  : docData?.result?.firstName + docData?.result?.lastName,
              dateOfBirth: `${docData?.result?.dateOfBirth?.day}/${docData?.result?.dateOfBirth?.month}/${docData?.result?.dateOfBirth?.year}`,
            },
          });
        }
      })
      .catch((err) => {
        console.log('err', err);
        this.setState({
          isLoading: false,
        });
      });
  };

  saveData = () => {
    this.setState(
      {
        progress: 1,
      },
      () => {
        this.props.navigation.navigate('ProfessionalDetails');
      },
    );
    return;
    const body = {
      farmerName: this.state.documentData.name,
      dateOfBirth: this.state.documentData.dateOfBirth,
      docType: this.state.documentData.idType,
      documentNumber: this.state.documentData.idNumber,
      // gender: 'M',
    };
    console.log(body, 'body');

    fetch(SAVE_DOCUMENT_DATA, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        // 'x-api-key': 'bf7fe978-c0f1-11eb-8089-0200cd936042',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    })
      .then((response) => {
        if (response.ok) {
          return response
            .json()
            .then((resposeData) => Promise.resolve(resposeData));
        }
        return response.json().then((errorData) => Promise.reject(errorData));
      })
      .then(
        (responseJson) => {
          console.log('json suceess', responseJson);
          // this.setState(
          //   {
          //     progress: 1,
          //   },
          //   () => {
          //     this.props.navigation.navigate('ProfessionalDetails');
          //   },
          // );
        },
        (errors) => {
          console.log('errors', errors);
          let tempError = this.state.errors;
          tempError['globalError'] = 'Some error occured.';

          this.setState({
            isLoading: false,
            otpSent: false,
            errors: tempError,
          });
        },
      )
      .catch((error) => {
        console.log('error', error);
        let errors = this.state.errors;
        errors['globalError'] = 'Some error occured.';

        this.setState({
          isLoading: false,
          otpSent: false,
          errors: errors,
        });
      })
      .done();
  };

  render() {
    const {isDark} = this.props.agrxTheme;
    const {cropName, questionText, natureOfProblem} = this.state;
    return (
      <SafeAreaView style={{flex: 1}}>
        <Spinner visible={this.state.isLoading} />
        <KeyboardAwareScrollView
          keyboardShouldPersistTaps={'always'}
          contentContainerStyle={{
            flexGrow: 1,
            paddingHorizontal: 12,
          }}>
          <TextInput
            mode="outlined"
            label="Add your crop"
            placeholder="Add your crop"
            value={cropName}
            onChangeText={this.onChangeCropName}
            style={{
              width: '100%',
              backgroundColor: '#fff',
              alignSelf: 'center',
              marginTop: 8,
              borderRadius: 20,
            }}
            multiline={true}
            underlineColor="transparent"
            underlineColorAndroid="transparent"
          />

          <TextInput
            mode="outlined"
            label="Ask question to community"
            placeholder="Ask question to community"
            value={questionText}
            onChangeText={this.onChangeQuestion}
            style={{
              width: '100%',
              backgroundColor: '#fff',
              alignSelf: 'center',
              marginTop: 8,
              borderRadius: 20,
            }}
            multiline={true}
            numberOfLines={4}
            underlineColor="transparent"
            underlineColorAndroid="transparent"
          />

          <TextInput
            mode="outlined"
            label="Nature of problem"
            placeholder="Nature of problem"
            value={natureOfProblem}
            onChangeText={this.onChangeCropNature}
            style={{
              width: '100%',
              backgroundColor: '#fff',
              alignSelf: 'center',
              marginTop: 8,
              borderRadius: 20,
            }}
            multiline={true}
            numberOfLines={4}
            underlineColor="transparent"
            underlineColorAndroid="transparent"
          />

          <Button
            mode="contained"
            style={{borderRadius: 2.5, marginTop: 14, marginBottom: 12}}
            onPress={() => {
              this.props.navigation.goBack();
            }}>
            <Text
              style={{
                fontSize: 18,
                color: '#fff',
                textTransform: 'none',
                fontWeight: '500',
              }}>
              Send
            </Text>
          </Button>
        </KeyboardAwareScrollView>
      </SafeAreaView>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    agrxTheme: state.agrxTheme,
  };
};

export default connect(mapStateToProps, {})(CreatePost);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eff2f5',
  },
  containerDark: {
    flex: 1,
    backgroundColor: AgrxColors.darkBackground,
  },
  updateText: {
    marginTop: 12,

    fontSize: 25,
    fontWeight: '600',
    marginBottom: 12,
    width: '100%',
  },
  updateTextDark: {
    marginTop: 12,

    fontSize: 25,
    fontWeight: '600',
    marginBottom: 12,
    width: '100%',
    color: AgrxColors.darkText,
  },
  inputStyle: {backgroundColor: '#fff', width: '100%'},
  inputStyleDark: {backgroundColor: AgrxColors.darkBackground, width: '100%'},
  innerContainer: {
    marginHorizontal: 14,
  },
  buttonStyle: {
    borderRadius: 2.5,
    marginTop: 3,
    marginBottom: 12,
    width: '80%',
    alignSelf: 'center',
  },
  resetButtonStyle: {
    borderRadius: 2.5,
    borderColor: '#6C757D',
    marginTop: 14,
    marginBottom: 12,
    width: '80%',
    alignSelf: 'center',
  },
  subheadingText: {
    fontSize: 16,
    color: '#6C757D',
    marginBottom: 25,
  },
  errorLabel: {
    color: '#bd3b49',
    fontSize: 16,
    marginVertical: 8,
    fontWeight: '600',
  },
});
