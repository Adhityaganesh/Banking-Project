import React, {Component} from 'react';
import {Text, View} from 'react-native';

export class Library extends Component {
  render() {
    return (
      <View>
        <Text> Library </Text>
      </View>
    );
  }
}

export default Library;
