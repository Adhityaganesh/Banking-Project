export const API_BASE_URL = 'http://3.129.163.178:9090';
export const MAP_API_KEY = 'AIzaSyDLLbugsbAjGSkWzwLDg6Aii8gpss3JCDo';

export const SEND_OTP = API_BASE_URL + '/get/getOtp/';
export const VERIFY_OTP = API_BASE_URL + '/get/otpVerify';
export const SAVE_USER_DATA = API_BASE_URL + '/get/saveData';
export const UPLOAD_IMAGE = API_BASE_URL + '/file/upload-file';
export const SAVE_DOCUMENT_DATA = API_BASE_URL + '/file/saveFarmerData';

export const PROFESSIONAL_DETAILS = API_BASE_URL + '/category/get/';

export const SEARCH_AUTOCOMPLETE =
  'https://maps.googleapis.com/maps/api/place/autocomplete/';
export const SEARCH_ADDRESS = 'https://maps.googleapis.com/maps/api/geocode/';
