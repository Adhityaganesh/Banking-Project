import {combineReducers} from 'redux';
import myChannels from './myChannels.js';

import agrxTheme from './agrxTheme.js';

export default combineReducers({
  myChannels,
  agrxTheme,
});
