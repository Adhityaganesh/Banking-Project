export const TASK_DATA = 'TASK_DATA';
export const DARK_MODE = 'DARK_MODE';
